﻿using System;
using System.Collections;

namespace ConsoleApp13
{
    class Program
    {
        static void Main()
        {
            ArrayList colcadenas = new ArrayList();
            //agregar un elemento con ell add
            colcadenas.Add("uno");
            colcadenas.Add("dos");
            colcadenas.Add("tres");

            foreach (string cadena in colcadenas)
            {

                Console.WriteLine(cadena);

            }


            Console.WriteLine("-----------------------------");

            //No  puedes usar double,float , etc
            ArrayList colnumeros = new ArrayList();
            colnumeros.Add(1);
            colnumeros.Add(2);
            colnumeros.Add(3);

            foreach(int numero in colnumeros )
            {
                Console.WriteLine(numero);

            }

            Console.WriteLine("-----------------------------");

            for (int i = 0; i < colnumeros.Count; i++)
            {
                Console.WriteLine(colnumeros[i]);


            }
        Console.WriteLine("-----------------------------");
            colnumeros.Add(3.1416f);
            colnumeros.Add(23456789);
            
            for(int i=0; i< colnumeros.Count;i++)
            {
                if (i < 3)
                {
                    int num = (int)colnumeros[i];
                    Console.WriteLine(num);
                }

                

                if (i==3)
                {
                    float num = (float)colnumeros[i];
                    
                
                }
                if (i==4)
                {
                    int num = (int)colnumeros[i];
                }
                

            }
            Console.WriteLine("-----------------------------");

            colnumeros.Remove(3.1416f);
            Console.WriteLine(colnumeros[3]);

            colcadenas.RemoveAt(0);
            Console.WriteLine(colcadenas[0]);
            Console.WriteLine("-----------------------------");

            colcadenas.Add("20");
            colcadenas.Add("25");



            Console.WriteLine("La suma de los numeros 20 y 1 Es;");
            int sum = int.Parse(colcadenas[colcadenas.IndexOf("20")].ToString()) + (int)colnumeros[0];
            Console.WriteLine(sum);



        }
    }
}
