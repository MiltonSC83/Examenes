﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MessageBox
{
    public partial class Form1 : Form
    {
        private MessageBoxButtons tipobotones;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Botones_CheckedChanged(object sender, EventArgs e)
        {
            if(sender == ac_radioButton)
            {
                tipobotones = MessageBoxButtons.OK;
            }
            else if(sender == acc_radioButton)
            {
                tipobotones = MessageBoxButtons.OKCancel;
            }
            else if (sender == ari_radioButton)
            {
                tipobotones = MessageBoxButtons.AbortRetryIgnore;
            }
            else if (sender == SNC_radioButton)
            {
                tipobotones = MessageBoxButtons.YesNoCancel;
            }
            else if (sender == RC_radioButton)
            {
                tipobotones = MessageBoxButtons.RetryCancel;
            }
        }
    }
}
