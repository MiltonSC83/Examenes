﻿namespace MessageBox
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.icons_groupBox = new System.Windows.Forms.GroupBox();
            this.Adv_radioButton = new System.Windows.Forms.RadioButton();
            this.Pre_radioButton = new System.Windows.Forms.RadioButton();
            this.Exc_radioButton = new System.Windows.Forms.RadioButton();
            this.Err_radioButton = new System.Windows.Forms.RadioButton();
            this.ast_radioButton = new System.Windows.Forms.RadioButton();
            this.Buttons_groupBox = new System.Windows.Forms.GroupBox();
            this.RC_radioButton = new System.Windows.Forms.RadioButton();
            this.SNC_radioButton = new System.Windows.Forms.RadioButton();
            this.ari_radioButton = new System.Windows.Forms.RadioButton();
            this.acc_radioButton = new System.Windows.Forms.RadioButton();
            this.ac_radioButton = new System.Windows.Forms.RadioButton();
            this.icons_groupBox.SuspendLayout();
            this.Buttons_groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // icons_groupBox
            // 
            this.icons_groupBox.Controls.Add(this.Adv_radioButton);
            this.icons_groupBox.Controls.Add(this.Pre_radioButton);
            this.icons_groupBox.Controls.Add(this.Exc_radioButton);
            this.icons_groupBox.Controls.Add(this.Err_radioButton);
            this.icons_groupBox.Controls.Add(this.ast_radioButton);
            this.icons_groupBox.Location = new System.Drawing.Point(386, 12);
            this.icons_groupBox.Name = "icons_groupBox";
            this.icons_groupBox.Size = new System.Drawing.Size(413, 436);
            this.icons_groupBox.TabIndex = 0;
            this.icons_groupBox.TabStop = false;
            this.icons_groupBox.Text = "Icononos";
            // 
            // Adv_radioButton
            // 
            this.Adv_radioButton.AutoSize = true;
            this.Adv_radioButton.Location = new System.Drawing.Point(129, 339);
            this.Adv_radioButton.Name = "Adv_radioButton";
            this.Adv_radioButton.Size = new System.Drawing.Size(82, 17);
            this.Adv_radioButton.TabIndex = 9;
            this.Adv_radioButton.TabStop = true;
            this.Adv_radioButton.Text = "Advertencia";
            this.Adv_radioButton.UseVisualStyleBackColor = true;
            // 
            // Pre_radioButton
            // 
            this.Pre_radioButton.AutoSize = true;
            this.Pre_radioButton.Location = new System.Drawing.Point(129, 266);
            this.Pre_radioButton.Name = "Pre_radioButton";
            this.Pre_radioButton.Size = new System.Drawing.Size(68, 17);
            this.Pre_radioButton.TabIndex = 8;
            this.Pre_radioButton.TabStop = true;
            this.Pre_radioButton.Text = "Pregunta";
            this.Pre_radioButton.UseVisualStyleBackColor = true;
            // 
            // Exc_radioButton
            // 
            this.Exc_radioButton.AutoSize = true;
            this.Exc_radioButton.Location = new System.Drawing.Point(129, 182);
            this.Exc_radioButton.Name = "Exc_radioButton";
            this.Exc_radioButton.Size = new System.Drawing.Size(85, 17);
            this.Exc_radioButton.TabIndex = 7;
            this.Exc_radioButton.TabStop = true;
            this.Exc_radioButton.Text = "Exclamación";
            this.Exc_radioButton.UseVisualStyleBackColor = true;
            // 
            // Err_radioButton
            // 
            this.Err_radioButton.AutoSize = true;
            this.Err_radioButton.Location = new System.Drawing.Point(129, 105);
            this.Err_radioButton.Name = "Err_radioButton";
            this.Err_radioButton.Size = new System.Drawing.Size(47, 17);
            this.Err_radioButton.TabIndex = 6;
            this.Err_radioButton.TabStop = true;
            this.Err_radioButton.Text = "Error";
            this.Err_radioButton.UseVisualStyleBackColor = true;
            // 
            // ast_radioButton
            // 
            this.ast_radioButton.AutoSize = true;
            this.ast_radioButton.Location = new System.Drawing.Point(129, 35);
            this.ast_radioButton.Name = "ast_radioButton";
            this.ast_radioButton.Size = new System.Drawing.Size(68, 17);
            this.ast_radioButton.TabIndex = 5;
            this.ast_radioButton.TabStop = true;
            this.ast_radioButton.Text = "Asterisco";
            this.ast_radioButton.UseVisualStyleBackColor = true;
            // 
            // Buttons_groupBox
            // 
            this.Buttons_groupBox.Controls.Add(this.RC_radioButton);
            this.Buttons_groupBox.Controls.Add(this.SNC_radioButton);
            this.Buttons_groupBox.Controls.Add(this.ari_radioButton);
            this.Buttons_groupBox.Controls.Add(this.acc_radioButton);
            this.Buttons_groupBox.Controls.Add(this.ac_radioButton);
            this.Buttons_groupBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Buttons_groupBox.Location = new System.Drawing.Point(12, 12);
            this.Buttons_groupBox.Name = "Buttons_groupBox";
            this.Buttons_groupBox.Size = new System.Drawing.Size(368, 426);
            this.Buttons_groupBox.TabIndex = 0;
            this.Buttons_groupBox.TabStop = false;
            this.Buttons_groupBox.Text = "Botones";
            // 
            // RC_radioButton
            // 
            this.RC_radioButton.AutoSize = true;
            this.RC_radioButton.Location = new System.Drawing.Point(68, 339);
            this.RC_radioButton.Name = "RC_radioButton";
            this.RC_radioButton.Size = new System.Drawing.Size(125, 17);
            this.RC_radioButton.TabIndex = 4;
            this.RC_radioButton.TabStop = true;
            this.RC_radioButton.Text = "Reintentar - Cancelar";
            this.RC_radioButton.UseVisualStyleBackColor = true;
            this.RC_radioButton.CheckedChanged += new System.EventHandler(this.Botones_CheckedChanged);
            // 
            // SNC_radioButton
            // 
            this.SNC_radioButton.AutoSize = true;
            this.SNC_radioButton.Location = new System.Drawing.Point(68, 266);
            this.SNC_radioButton.Name = "SNC_radioButton";
            this.SNC_radioButton.Size = new System.Drawing.Size(108, 17);
            this.SNC_radioButton.TabIndex = 3;
            this.SNC_radioButton.TabStop = true;
            this.SNC_radioButton.Text = "Si - No - Cancelar";
            this.SNC_radioButton.UseVisualStyleBackColor = true;
            this.SNC_radioButton.CheckedChanged += new System.EventHandler(this.Botones_CheckedChanged);
            // 
            // ari_radioButton
            // 
            this.ari_radioButton.AutoSize = true;
            this.ari_radioButton.Location = new System.Drawing.Point(68, 182);
            this.ari_radioButton.Name = "ari_radioButton";
            this.ari_radioButton.Size = new System.Drawing.Size(159, 17);
            this.ari_radioButton.TabIndex = 2;
            this.ari_radioButton.TabStop = true;
            this.ari_radioButton.Text = "Abortar - Reintentar - Ignorar";
            this.ari_radioButton.UseVisualStyleBackColor = true;
            this.ari_radioButton.CheckedChanged += new System.EventHandler(this.Botones_CheckedChanged);
            // 
            // acc_radioButton
            // 
            this.acc_radioButton.AutoSize = true;
            this.acc_radioButton.Location = new System.Drawing.Point(68, 105);
            this.acc_radioButton.Name = "acc_radioButton";
            this.acc_radioButton.Size = new System.Drawing.Size(113, 17);
            this.acc_radioButton.TabIndex = 1;
            this.acc_radioButton.TabStop = true;
            this.acc_radioButton.Text = "Aceptar - Cancelar";
            this.acc_radioButton.UseVisualStyleBackColor = true;
            this.acc_radioButton.CheckedChanged += new System.EventHandler(this.Botones_CheckedChanged);
            // 
            // ac_radioButton
            // 
            this.ac_radioButton.AutoSize = true;
            this.ac_radioButton.Location = new System.Drawing.Point(68, 35);
            this.ac_radioButton.Name = "ac_radioButton";
            this.ac_radioButton.Size = new System.Drawing.Size(62, 17);
            this.ac_radioButton.TabIndex = 0;
            this.ac_radioButton.TabStop = true;
            this.ac_radioButton.Text = "Aceptar";
            this.ac_radioButton.UseVisualStyleBackColor = true;
            this.ac_radioButton.CheckedChanged += new System.EventHandler(this.Botones_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Buttons_groupBox);
            this.Controls.Add(this.icons_groupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.icons_groupBox.ResumeLayout(false);
            this.icons_groupBox.PerformLayout();
            this.Buttons_groupBox.ResumeLayout(false);
            this.Buttons_groupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox icons_groupBox;
        private System.Windows.Forms.GroupBox Buttons_groupBox;
        private System.Windows.Forms.RadioButton Adv_radioButton;
        private System.Windows.Forms.RadioButton Pre_radioButton;
        private System.Windows.Forms.RadioButton Exc_radioButton;
        private System.Windows.Forms.RadioButton Err_radioButton;
        private System.Windows.Forms.RadioButton ast_radioButton;
        private System.Windows.Forms.RadioButton RC_radioButton;
        private System.Windows.Forms.RadioButton SNC_radioButton;
        private System.Windows.Forms.RadioButton ari_radioButton;
        private System.Windows.Forms.RadioButton acc_radioButton;
        private System.Windows.Forms.RadioButton ac_radioButton;
    }
}

