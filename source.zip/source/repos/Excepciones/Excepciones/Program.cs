﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    class Program
    {
        static void Main(string[] args)
        {
            /*//DivideByZeroException Class
            int number1 = 3000;
            int number2 = 0;
            try
            {
                Console.WriteLine(number1 / number2);
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("Division of {0} by zero.", number1);
            }
            Console.Read();*/
            //OverflowException Class 
            //OverflowException Class 
            /*int value = 780000000;
            checked
            {
                try
                {
                    // Square the original value.
                    int square = value * value;
                    Console.WriteLine("{0} ^ 2 = {1}", value, square);
                }
                catch (OverflowException)
                {
                    double square = Math.Pow(value, 2);
                    Console.WriteLine("Exception: {0} > {1:E}.",
                                      square, Int32.MaxValue);
                }
            }
            // The example displays the following output:
            //       Exception: 6.084E+17 > 2.147484E+009.
            
            */
            /*string[] names = { "Dog", "Cat", "Fish" };
            Object[] objs = (Object[])names;

            try
            {
                objs[2] = "Mouse";

                foreach (object animalName in objs)
                {
                    System.Console.WriteLine(animalName);
                }
            }
            catch (System.ArrayTypeMismatchException)
            {
                // Not reached; "Mouse" is of the correct type.
                System.Console.WriteLine("Exception Thrown.");
            }

            try
            {
                Object obj = (Object)13;
                objs[2] = obj;
            }
            catch (System.ArrayTypeMismatchException)
            {
                // Always reached, 13 is not a string.
                System.Console.WriteLine(
                    "New element is not of the correct type.");
            }

            // Set objs to an array of objects instead of 
            // an array of strings.
            objs = new Object[3];
            try
            {
                objs[0] = (Object)"Turtle";
                objs[1] = (Object)12;
                objs[2] = (Object)2.341;

                foreach (object element in objs)
                {
                    System.Console.WriteLine(element);
                }
            }
            catch (System.ArrayTypeMismatchException)
            {
                // ArrayTypeMismatchException is not thrown this time.
                System.Console.WriteLine("Exception Thrown.");
            }*/
            List<Char> characters = new List<Char>();
            characters.InsertRange(0, new Char[] { 'a', 'b', 'c', 'd', 'e', 'f' });
            for (int ctr = 0; ctr < characters.Count; ctr++)
                Console.Write("'{0}'    ", characters[ctr]);
            Console.Read();
        }


    }
}
