﻿using System;

namespace Ejemplo
{
    class Program
    {
        static void Main()
        {
            Cliente cliente;

            cliente.Nombre = "Armando";
            cliente.Telefono = "5560832574";
            cliente.saldo = new float[12];
            
            Console.WriteLine("Nombre {0} \nTelefono {1}\n", cliente.Nombre, cliente.Telefono);
            for (int i=0; i<cliente.saldo.Length; i++)
            {
                Console.WriteLine("Ingresa el saldo de {0}", Meses.Enero + i);
                cliente.saldo[i]=float.Parse(Console.ReadLine());
            }

            ///////
            Cliente[] clientes = new Cliente[3];
            for (int i = 0; i < clientes.Length; i++)
            {
                Console.WriteLine("\n\nIngresa el nombre: ");
                clientes[i].Nombre = Console.ReadLine();
                Console.WriteLine("Ingresa el telefono: ");
                clientes[i].Telefono = Console.ReadLine();
                /////
                Console.WriteLine("Ingresa la dirección del usuario.");
                Console.WriteLine("Ingresa la calle: ");
                clientes[i].direccion.Calle = Console.ReadLine();
                Console.WriteLine("Ingresa la colonia: ");
                clientes[i].direccion.Colonia = Console.ReadLine();
                Console.WriteLine("Ingresa la ciudad: ");
                clientes[i].direccion.Ciudad = Console.ReadLine();
            }
            for (int i=0; i<clientes.Length; i++)
            {
                Console.WriteLine("\nNombre: {0} \nTelefono: {1}\n*DIRECCIÓN\n Calle: {2}\n Colonia: {3}\n Ciudad: {4}\n", clientes[i].Nombre, clientes[i].Telefono, clientes[i].direccion.Calle, clientes[i].direccion.Colonia, clientes[i].direccion.Ciudad);
            }
        }
    } 

    public struct Cliente //estructura o registro es lo mismo
    {
        public string Nombre;
        public string Telefono;
        public Direccion direccion;
        public float [] saldo;
        public bool Moroso;
    }

    public struct Direccion
    {
        public string Calle;
        public string Colonia;
        public string Ciudad;
    }

    public enum Meses //también se le conoce como numeros magicos
        //por default, el tipo de dato al que lo asocia es int
    {
        Enero=1,
        Febrero,
        Marzo,
        Abril,
        Mayo,
        Junio,
        Julio,
        Agosto,
        Septiembre,
        Octubre,
        Noviembre,
        Diciembre,
    }
}
