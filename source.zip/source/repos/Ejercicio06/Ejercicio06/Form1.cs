﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio06
{
    public partial class Form1 : Form
    {
        private Graphics papel;
        public Form1()
        {
            InitializeComponent();
            button1.BackColor = Color.Black;
            papel = pictureBox1.CreateGraphics();
            numericUpDown1.Maximum = 10;
            numericUpDown1.Minimum = 0;
            numericUpDown1.Value = 4;
           
            
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                button1.BackColor = colorDialog1.Color;
            }
        }

            private void button2_Click(object sender, EventArgs e)
            {
               
                papel.Clear(Color.White);
            }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
         
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if(e.Button==MouseButtons.Left)
            {
                Console.WriteLine(e.Location.X + "," + e.Location.Y);
                Brush pincel = new SolidBrush(colorDialog1.Color);
               

                papel.FillEllipse(pincel, e.Location.X, e.Location.Y, Convert.ToInt32(numericUpDown1.Value), Convert.ToInt32(numericUpDown1.Value));

              
 
            }

        }

        private void checkBox1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked==true)
            {
                //Console.WriteLine("Seleccionado");
                //pictureBox1.Cursor = Cursors.Cross;

                

                
            }

            else
            {
                pictureBox1.Cursor = Cursors.Arrow;
            }
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {

            Console.WriteLine(e.Location.X + "," + e.Location.Y);
            Brush pincel = new SolidBrush(colorDialog1.Color);


            papel.FillEllipse(pincel, e.Location.X, e.Location.Y, Convert.ToInt32(numericUpDown1.Value), Convert.ToInt32(numericUpDown1.Value));

        }
    }
}
