﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    class Contenedor
    {
        public delegate void MiManejadorEvento();
        public event MiManejadorEvento DisparaEvento;

        public void Dispara()
            {

            DisparaEvento();

            }


    }
}
