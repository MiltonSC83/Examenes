﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    class Program
    {
        private bool enciende;





        public bool Enciende
        {
            get
            {
                return enciende;

            }

            set
            {
                Enciende = value;

            }


        }
        public void Metodo1()
        {
            Console.WriteLine("Evento 1 disparado desde program");
        }
        public void Metodo2()
        {
            Console.WriteLine("Evento 2 disparado desde program");
        }


       

        static void Main()
        {
            Program program = new Program();
            Contenedor contenedor = new Contenedor();

            contenedor.DisparaEvento += program.Metodo1; 
            contenedor.DisparaEvento += program.Metodo2;
           
            contenedor.Dispara();
            contenedor.DisparaEvento -= program.Metodo2;
            Console.WriteLine("Ya no existe el metodo 2;");
            contenedor.Dispara();
            contenedor.DisparaEvento += program.Encendido;



            contenedor.Dispara();
          
            
        }


        Program.Enciende = true;

        if(Program.Enciende == true)
        { 
            contenedor Dispara();

        }
    }
}
