﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class CNúmerosracionales
    {
        //Atributos
        private int denominador, numerador;

        //Constructor
        public CNúmerosracionales(int d,int n)
        {
            denominador = d;
            numerador = n;
        }

        public CNúmerosracionales()
        {
            denominador = 1;
            numerador = 1;
        }

        public CNúmerosracionales(int entero)
        {
            numerador = entero;
            denominador = 1;
        }

        //propiedades
        public int Numerador
        {
            set { numerador = value; }
            get { return numerador; }
        }

        public int Denominador
        {
            set { denominador = value; }
            get { return denominador; }
        }

        //Métodos
        public string RepresentarNR()
        {
            string NR = denominador.ToString() + "/" + numerador.ToString();
            return NR;
        }
    }
}
