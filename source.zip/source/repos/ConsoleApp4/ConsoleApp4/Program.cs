﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Crear una clase
            CNúmerosracionales racional3 = new CNúmerosracionales(5, 9);
            CNúmerosracionales racional2 = new CNúmerosracionales(5, 78);
            CNúmerosracionales racional1 = new CNúmerosracionales();

            Console.Write("El número racional es {0}, {1}, {2}", racional1.RepresentarNR(), racional2.RepresentarNR(),racional3.RepresentarNR());

            





            Console.ReadKey();


        }
    }
}
