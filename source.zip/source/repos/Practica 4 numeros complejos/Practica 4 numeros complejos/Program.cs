﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_4_numeros_complejos
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Representación de números complejos");
            Console.WriteLine("Dame el número real:");
            int nr1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Dame el número complejo:");
            int nc1 = int.Parse(Console.ReadLine());

        }
    }
}
