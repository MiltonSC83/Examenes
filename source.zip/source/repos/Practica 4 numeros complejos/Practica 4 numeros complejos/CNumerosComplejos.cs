﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_4_numeros_complejos
{
    class CNumerosComplejos
    {
        //Atributos
        private int numreal, numcomplejo;

        //Constructor
        public CNumerosComplejos(int numreal, int numcomplejo)
        {
            this.numreal = numreal;
            this.numcomplejo = numcomplejo;
        }

        //Propiedades
        public int Numreal
        {
            set { numreal = value; }
            get { return numreal; }
        }
        public int Numcomplejo
        {
            set { numcomplejo = value; }
            get { return numcomplejo; }
        }

        //Métodos
        public string RepresentarNC(int numreal, int numcomplejo)
        {
            string Rep = "El número complejo es: " + numreal.ToString() + "+" + numcomplejo.ToString() + "i";
            return Rep;
        }

    }
}
