﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examen4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            List<List<string>> ListaNumeros;
            ListaNumeros = new List<List<string>>();

            List<string> Version;
            Version = new List<string>();

            List<string> Nombre;
            Nombre = new List<string>();

            List<string> Modelo;
            Modelo = new List<string>();

            ListaNumeros.Add(Version);
            ListaNumeros.Add(Nombre);
            ListaNumeros.Add(Modelo);

            dataGridView1.ColumnCount = 4;
            dataGridView1.Columns[0].Name = "Versión";
            dataGridView1.Columns[1].Name = "Nombre";
            dataGridView1.Columns[2].Name = "Modelo";
            dataGridView1.Columns[3].Name = "Tipo";

            Version.Add("Alejandro");
            Version.Add("Erick");
            Version.Add("Milton");
            Nombre.Add("Perez");
            Nombre.Add("Contreras");
            Nombre.Add("Sosa");
            Modelo.Add("12345");
            Modelo.Add("67890");
            Modelo.Add("314308067");
            

            for (int i = 0; i < ListaNumeros.Count; i++)
            {
                dataGridView1.Rows.Add();
                for (int j = 0; j < 3; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = ListaNumeros[j][i];
                }

            }

            


        }
    }
}
