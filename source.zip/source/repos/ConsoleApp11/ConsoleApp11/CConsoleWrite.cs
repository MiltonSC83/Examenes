﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    class CConsoleWrite
    {
        

        //Metodos
        public void imprimir(string mensaje)
        {
            Console.Write(mensaje);
        }
        public void imprimir(string mensaje, int columna, int fila)
        {
            Console.SetCursorPosition(columna, fila);
            Console.Write(mensaje);
        }
        public void imprimir(string mensaje, int columna, int fila, ConsoleColor colorletra)
        {
            Console.ForegroundColor = colorletra;
            imprimir(mensaje, columna, fila);
        }
        public void imprimir(string mensaje, int columna, int fila, ConsoleColor colorletra, ConsoleColor colorfondo)
        {
            Console.BackgroundColor = colorfondo;
            imprimir(mensaje, columna, fila, colorletra);
        }

    }
}
