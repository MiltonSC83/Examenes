﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    class Program
    {
        static void Main(string[] args)
        {
            CConsoleWrite ventana = new CConsoleWrite();

            ventana.imprimir("Técnicas de programación 2019-1");

            ventana.imprimir("Técnicas de programación 2019-1", 30, 5);

            ventana.imprimir("Técnicas de programación 2019-1", 45, 7, ConsoleColor.DarkMagenta);

            ventana.imprimir("Técnicas de programación 2019-1", 60, 10, ConsoleColor.DarkMagenta, ConsoleColor.Red);

            ventana.imprimir(Console.ReadLine());


            Console.ReadKey();
        }
    }
}
