﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arreglosmultidim
{
    public class CMatriz2x2
    {
        //Atributos
        int[,] m2x2;

        //Constructor
        public CMatriz2x2 (int fila, int columna)
            {
            m2x2 = new int [fila, columna];
            }
        public CMatriz2x2 ()
        {
            m2x2 = new int[2, 2];
        }

        public CMatriz2x2(string al)
        {
            m2x2 = new int[2, 2];
            Random numaleatorio = new Random();
            if (al == "aleatoria")
            {
                for (int i = 0; i < 2; i++)
                {
                    for (int j = 0; j < 2; j++)
                    {
                        int s = 1;
                        do
                        {
                            int n = numaleatorio.Next(1, 5);

                            if (AccederValor(0, 0) != n && AccederValor(0, 1) != n && AccederValor(1, 0) != n && AccederValor(1, 1) != n)
                            {
                                ModificarValor(i, j, n);
                                s = 3;
                            }
                        } while (s == 1);
                    }
                }
            }
        }
        //Métodos
        public void ModificarValor(int fila,int columna,int valor)
        {
            m2x2[fila, columna] = valor;
        }

        public int AccederValor(int fila, int columna)
        {
            int v = m2x2[fila, columna];
            return v;
        }

        public void RepresentaConsola()
        {
            for(int i=0; i<2; i++)
            {
                for(int j=0; j<2; j++)
                {
                    //Console.WriteLine("m2x2[{0}, {1}] = {2}", i, j, m2x2[i, j]);
                    Console.Write(" {0} ", m2x2[i, j]);
                }
                Console.WriteLine();
            }
        }

        public void MultiplicarEscalar(int escalar)
        {
            for(int i = 0; i <2; i++)
            {
                for(int j = 0; j <2; j++)
                {
                    ModificarValor(i, j, (escalar * AccederValor(i, j)));
                }
            }
        }

     
    }
}
