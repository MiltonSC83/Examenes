﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Puzzle
{
    class Cmatriz3x3
    {
        //Atributos
        int[,] m3x3;

        //Constructor
        public Cmatriz3x3()
        {
            m3x3 = new int[3, 3]; //Creación de la matriz

            Random valor = new Random(); //Rellenar con numeros aleatoriamente

            for (int i = 0; i < 3; i++)
            {
                //tablero[i, 0] = valor.Next(1, 9);
                for (int j = 0; j < 3; j++)
                {
                    bool bandera = false;
                    do
                    {
                        int aux = valor.Next(1, 10);
                        if (AccederElemento(0, 0) != aux && AccederElemento(0, 1) != aux && AccederElemento(0, 2) != aux && AccederElemento(1, 0) != aux &&
                            AccederElemento(1, 1) != aux && AccederElemento(1, 2) != aux && AccederElemento(2, 0) != aux && AccederElemento(2, 1) != aux &&
                            AccederElemento(2, 2) != aux)
                        {
                            ModificarElemento(i, j, aux);
                            bandera = true;
                        }

                    } while (bandera == false);
                }
            }
        }

        public Cmatriz3x3(int fila, int col)
        {
            m3x3 = new int[fila, col];
        }

        //Métodos

        public void RepresentarConsolaMatriz()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(" {0} ", m3x3[i, j]);
                }
                Console.WriteLine();
            }
        }

        public void ModificarElemento(int fila, int col, int val)
        {
            m3x3[fila, col] = val;
        }

        public int AccederElemento(int fila, int col)
        {
            return m3x3[fila, col];
        }

        public void MultiplicarEscalar(int escalar)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    ModificarElemento(i, j, (escalar * AccederElemento(i, j)));
                }
            }
        }
        /*
        public int[] Encontrar(int val)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (tablero[i, j] == val)
                    {
                        int[] indices = new int[2];
                        indices = {i,j};
                        return indices;
                    }
                    else{return [5,5]};
                }
            }
        }]*/

    }
}
