﻿using System;

namespace Manejodematrices
{
    public class Class1
    {
    }
}
