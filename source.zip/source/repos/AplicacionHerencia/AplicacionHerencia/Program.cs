﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicacionHerencia
{
    class Program
    {
        static void Main(string[] args)
        {
            int Base = 0;
            string BaseString="";
            int Altura = 0;
            string AlturaString = "";

            Console.WriteLine("Introduce la base");
            BaseString =Console.ReadLine();
            Base = Convert.ToInt16(BaseString);

            Console.WriteLine("Introduce la altura");
            AlturaString=Console.ReadLine();
            Altura = Convert.ToInt16(AlturaString);

            Console.ReadLine();

            Rectangulo Rect = new Rectangulo();

            Rect.setBase(Base);
            Rect.setAltura(Altura);

            Console.WriteLine("Area total = {0}", Rect.getArea());
            Console.ReadKey();
        }
    }
    }
