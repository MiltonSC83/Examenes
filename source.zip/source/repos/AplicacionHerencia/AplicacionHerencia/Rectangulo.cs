﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicacionHerencia
{
    class Rectangulo:Forma
    {
        public int getArea()
        {
            return (Base * Altura);
        }
    }
}
