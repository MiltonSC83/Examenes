﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicacionHerencia
{
    class Forma
    {
        protected int Base;
        protected int Altura;

        public void setBase(int b)
        {
            Base = b;
        }
        public void setAltura(int a)
        {
            Altura = a;
        }
    }
}
