﻿using System;
using System.Windows.Forms;

namespace Ejercicio03
{
    public partial class Form1 : Form
    {
        public Form1() //No tiene retorno
        {
            InitializeComponent();
            numericUpDown1.Minimum = 1;
            numericUpDown1.Maximum= 1000;
            numericUpDown1.Value= 500;
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            Random generador = new Random();
            int numero = generador.Next(1, 1000); //Darle valor al metodo
            numericUpDown1.Value = numero;


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            LlenarLista();
        }

        private void LlenarLista()
        {
            Random generador = new Random(); //Generador es un objeto 
            for (int i=1; i<=100; i++)
            {
                listBox1.Items.Add(generador.Next(1,1000)); //Next es el evento que te permite generar numeros aleatorios


            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LlenarLista(numericUpDown1.Value);
        }

        private void LlenarLista(decimal value)
        {
            Random generador = new Random(); //Generador es un objeto 
            for (int i = 1; i <= value; i++)
            {
                listBox1.Items.Add(generador.Next(1, 1000)); //Next es el evento que te permite generar numeros aleatorios


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            label1.Text = "";
            label2.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Convert.ToString(listBox1.Items.Count));
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int valor = Convert.ToInt32(numericUpDown1.Value);
            string cadena = Convert.ToString(listBox1.Items[valor]);
            MessageBox.Show(cadena);
          
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int sumaFor = 0;
                for(int i=0;  i<=listBox1.Items.Count;i++) //Listbox1.Items.Count nos da el número de elementos que tiene la lista de la caja

                {
                sumaFor = sumaFor + Convert.ToInt32(listBox1.Items[1]);
                }

             
            label1.Text = Convert.ToString(sumaFor); //O 

        }

        /* 
         int sumaForEach=0;
         foreach(int numero in listBox1.Items) "Se pone el nombre de la lista y el  in significa lo mismo que:  listBox1.Items[1]"
         {
            sumaForEach=sumaForEach+numero;
         }
          
            label2.Text=sumaForEach + "";
         */

        private void button7_Click(object sender, EventArgs e)
        {

            int sumaForEach = 0;
            foreach (int numero in listBox1.Items)
         {
                sumaForEach = sumaForEach + numero;
            }

            label2.Text = (sumaForEach)/listBox1.Items.Count + "";
        }

        private void button8_Click(object sender, EventArgs e)
        {

            int mayor = Convert.ToInt32(listBox1.Items[0]);
            foreach (int numero in listBox1.Items)

            {
                if (numero > mayor)
                {
                    mayor = numero;
                }

            }

            label3.Text = mayor + "";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int menor = Convert.ToInt32(listBox1.Items[0]);
            foreach (int numero in listBox1.Items)

            {
                if (numero < menor)
                {
                    menor = numero;
                }

            }

            label4.Text = menor + "";


        }
    }
}
