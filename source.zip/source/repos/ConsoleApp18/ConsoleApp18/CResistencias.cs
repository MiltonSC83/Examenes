﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp18
{
    class CResistencias
    {
        public double RES2(double res1, double res2)
        {
            double Res = res1 + res2;
            return Res;
        }
        public double RES3(double res1, double res2, double res3)
        {
            double Res = res1 + res2 + res3;
            return Res;
        }
        public double REP2(double res1, double res2)
        {
            double Res = 1 / ((1 / res1) + (1 / res2));
            return Res;
        }
        public double REP3(double res1, double res2, double res3)
        {
            double Res = 1 / ((1 / res1) + (1 / res2) + (1/res3));
            return Res;
        }

    }
}
