﻿using System;

namespace SobrecargaOperdaores
{
    class Program
    {
        static void Main()
        {
            Complejo c1 = new Complejo(2, 4);
            Complejo c2 = new Complejo(3, 5);
            Complejo c3 = c1 + c2;
            Complejo c4 = c1 * c3;
            Console.WriteLine("La suma de {0} + {1} = {2}", c1, c2, c3);
            Console.WriteLine("La multiplicacion de {0} + {1} = {2}", c1, c3, c4);

            try
            {
                Console.WriteLine("Introduce la parte real: ");
                float real = float.Parse(Console.ReadLine());

                Console.WriteLine("Introduce la parte imaginaria: ");
                float imaginaria = float.Parse(Console.ReadLine());
                c3 = new Complejo(real, imaginaria);

            }
            catch(FormatException error)
            {
                Console.WriteLine("error:"+error.Message);
            }
            catch
            {
                Console.WriteLine("Upps. Hay un error. Lo siento");
            }


        }
    }
}
