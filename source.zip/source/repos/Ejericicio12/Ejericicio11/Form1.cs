﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejericicio11
{
    public partial class Form1 : Form
    {
        private Graphics papel;
        private ColaSerpiente cabeza;
        private Comida manzana;
        private int puntos = 0;
        private int xdir=0, ydir=0;
        private Boolean ejex = true, ejey = true;
        private int paso = 10;
        public Form1()
        {
            InitializeComponent();
            papel = Canvas.CreateGraphics();
            //Cola Serpiente recibe dos valores 
            cabeza = new ColaSerpiente(10,10);
            manzana = new Comida(Canvas.Width, Canvas.Height);
            label2.Text = "0";
            Bucle.Start();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (ejex)
            {
                if (e.KeyCode==Keys.Up)
                {
                    ydir = -paso;
                    xdir = 0;
                    ejex = false;
                    ejey = true;
                }

                if (e.KeyCode==Keys.Down)
                {
                    ydir = paso;
                    xdir = 0;
                    ejex = false;
                    ejey = true;
                }
            }

            if (ejey)
            {
                if (e.KeyCode == Keys.Right)
                {
                    ydir = 0;
                    xdir = paso;
                    ejex = true;
                    ejey = false;
                }

                if (e.KeyCode == Keys.Left)
                {
                    ydir = 0;
                    xdir = -paso;
                    ejex = true;
                    ejey = false;
                }
            }
        }

        private void Bucle_Tick(object sender, EventArgs e)
        {
            DibujarTodo();
            MoverTodo();
        }

        private void MoverTodo()
        {
            cabeza.Mover(cabeza.x+xdir,cabeza.y+ydir);
        }

        private void DibujarTodo()
        {
            papel.Clear(Color.White);
            cabeza.Dibujar(papel);
            manzana.Dibujar(papel);
        }
    }
}
