﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejericicio11
{
    public  class ElementoGráfico
    {
        //Se usa protected en vez de private para que las demas clases puedan heredar 

        protected int xValue, yValue, sizeValue; 
        public int x
        {
            get
            {
                return xValue;
            }
        }

        public int y
        {
            get
            {
                return yValue;
            }
        }

        public int Size
        {
            get
            {
                return sizeValue;
            }
        }

        public ElementoGráfico()
        {
            sizeValue = 10;
        }

        public Boolean Colisión(ElementoGráfico otro)
        {
            //hace refetencia al elemento gráfico en su valord e propiedad x y y 
            int difX = Math.Abs(this.x-otro.x);
            int difY = Math.Abs(this.y - otro.y);

            if(difX>=0 && difY<sizeValue && difY>=0 && difY<sizeValue)
            {
                return true; 
            }
            else
            {
                return false; 
            }
            


        }
    }
}
