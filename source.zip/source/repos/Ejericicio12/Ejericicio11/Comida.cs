﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejericicio11
{
    public class Comida:ElementoGráfico
    {
        private Random generador= new Random();
        //Se pone el el alto y el ancho del elemento que lo contine
        public Comida(int width,int height)
        {
            xValue = Generar(width / 2);
            yValue=Generar(height/2);
        }

        private int Generar(int v)
        {
            
            int num = generador.Next(0, v) * 10;
            return num;
        }
        public void Dibujar (Graphics papel)
        {
            Brush brocha = new SolidBrush(Color.Red);

            papel.FillRectangle(brocha, xValue, yValue, sizeValue, sizeValue);
        }
    }
}
