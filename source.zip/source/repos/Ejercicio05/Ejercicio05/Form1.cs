﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio05
{
    public partial class Form1 : Form
    {
        private Graphics papel;
        public Form1()
        {
            InitializeComponent();
            trackBar1.Minimum = 1;
            trackBar1.Maximum = pictureBox1.Width;
            trackBar1.Value = pictureBox1.Width/2;
            label3.Text = trackBar1.Value+"";
            papel = pictureBox1.CreateGraphics();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox3.Text = "";
            int inicio = Convert.ToInt32(textBox1.Text);
            int final = Convert.ToInt32(textBox2.Text);
            //List<int> primos = new List<int>();
            List <int> primos = ObtenerPrimos( inicio, final);
            foreach (int valor in primos)
            {
                textBox3.AppendText(valor+"\r\n"); 
            }
            
        }

        private List<int> ObtenerPrimos(int inicio, int final)
        {
            List<int> primos = new List<int>();
            for(int valor=inicio;valor<=final; valor++)
            {
                bool esPrimo = true;

                 if (valor<=1)
                  {
                    esPrimo = false; 
                  }

                 else
                 {
                    for (int div=2;div<valor; div++)

                    {
                        if (valor%div==0)
                        {
                            esPrimo = false;
                            break;
                        }
                    }

                 }
                 if (esPrimo)
                 {
                    primos.Add(valor);
                 }
            }
            return primos;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if (Esprimo(trackBar1.Value))
            {
                //Hago algo  
                Brush pincel = new SolidBrush(Color.Green);
                
            papel.Clear(Color.White);
           
            papel.FillEllipse(pincel, 0, 0, trackBar1.Value, trackBar1.Value);

            }
            else
            {
                Brush pincel = new SolidBrush(Color.Red);
                papel.Clear(Color.White);

                papel.FillEllipse(pincel, 0, 0, trackBar1.Value, trackBar1.Value);

            }

            label3.Text = Convert.ToString(trackBar1.Value);
        }

        private bool Esprimo(int value)
        {
            bool resultado = true;
            if (value <= 1)
            {
                resultado = false;
            }
            else
            {
                for (int div = 2; div < value; div++)
                {
                    if (value % div == 0)
                    {
                        resultado = false;
                        break;
                    }
                }
            }
            return resultado;
        }
    }
}

