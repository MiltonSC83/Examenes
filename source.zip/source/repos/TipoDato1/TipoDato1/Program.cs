﻿using System;

namespace TipoDato1
{
    class Program
    {
        static void Main(string[] args)
        {
            int intMivar = 2147483647;
            int intMivar2 = 1;

            int intMiresultado = intMivar + intMivar2;

            Console.WriteLine("La suma de {0} + {1} = {2} ", intMivar, intMivar2, intMiresultado);
        }
    }
}
