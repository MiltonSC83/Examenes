﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hello_world
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World");

            int num = 30;
            Console.Write(num);

            double nume = 30.33;
            Console.Write(nume);

            Boolean status = false;
            Console.Write(status);

            string message = "Hello";
            Console.Write(message);

            bool condition = false;

            int a=5;
            int b=10;

            if (condition)
            {
                a=b+1;
            }
            else
            {
                a=b+5;
            }
            Console.WriteLine(a);
        }
    }
}
