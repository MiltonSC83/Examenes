﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejericicio09
{
    public class Globo
    {
        private Graphics fondo;
        //Varibles de instancia
        //Constructor que inicializa esas variables
        //Metodo dibujar que dibuja circulos rellenos
        public int valorX, valorY, valorTam, valorAncho, valorLargo;


        public int X
        {
            get
            {
                return valorX;
            }

            set
            {
                valorX = value;
            }
        }

        public int Y
        {
            get
            {
                return valorY;
            }

            set
            {
                valorY = value;
            }
        }

        public Globo(int nuevaX, int nuevaY, int nuevoTam)
        {
            valorX = nuevaX;
            valorY = nuevaY;

            valorTam = nuevoTam;
        }

        public void Dibujar(Graphics fondo)

        {
            Brush pincel = new SolidBrush(Color.Purple);
            fondo.FillEllipse(pincel, valorX, valorY, valorAncho, valorLargo);
        }

    }
}
