﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejericicio09
{
    public partial class Form1 : Form
    {
        private Globo[] fiesta = new Globo[50];
        private Graphics fondo;
        private int contador = 0;
        private Random generador;
        //TrackBar tiene un rango de 1 a 1000
        //Inicio fijar el valor del track bar a la mitad 
        //Label sigue al valor del track bar
        //el intecalo del timer sigue al valor del track bar 
        //Botton inicar, incia el timer 
        // el boton de detener detiene el timer
        //El timer cad vez que hace tick hace
        //-----> elije dos coodenadas x y y aleatoriamente 
        //------> El rango es lño que mida el picure box
        //Con estos valores elije un valor "tam" aleatoriamente 
        // ----> el rango de valores entre 1 y 30 
        //Crear un globo con esas características (x,y,tam)
        //El globo se guarda en la posicion correspondiente del arreglo fiesta, lleva la cuenta contador
        //Así van guardando los globos hasta desbordar el arreglo 
        //No dejar que se desborde el arreglo 
        //Cuando identifiquen que ya se lleno, borren todo 
        //(Vuelvan a inicializar el arreglo y comiencen a llenarlo de nuevo)
        //Al final del tick deben borrar todo lo dibujado 
        //Posteriormente de que se borro todo lo dibujado recorrer el arreglo "Fiesta" y dibujen todo 


        public Form1()
        {
            InitializeComponent();
            trackBar1.Minimum = 1;
            trackBar1.Maximum = 1000;
            trackBar1.Value = 500;


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label1.Text = trackBar1.Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timerGlobos.Start();
            timerGlobos.Interval = trackBar1.Value;
            

        }

        private void timerGlobos_Tick(object sender, EventArgs e)
        {

         
            if (fiesta == null)

            {
                int xCoord = generador.Next(0, pictureBox1.Width);
                int yCoord = generador.Next(0, pictureBox1.Height);
                int tamGlobo= generador.Next(1,30);

                for (int i = 0; i < fiesta.Length; i++) ;
                {
                    Globo[] fiesta = new Globo[50];
                }

                
            }
        }

        private void DibujarGlobos()
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timerGlobos.Stop();
        }

        
    }
}
