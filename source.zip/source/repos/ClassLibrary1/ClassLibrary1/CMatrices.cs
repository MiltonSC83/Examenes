﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    class CMatriz2x2
    {
        //Atributos
        int[,] m2x2;
        
        //constructor
        public CMatriz2x2(int fila, int columna )
        {
            m2x2 = new int[fila, columna];
        }
        public CMatriz2x2()
        {
            m2x2 = new int[2, 2];
        }

        //Métodos
        public void Modificar(int fila,int columna, int valor)
        {
            m2x2[fila, columna] = valor; 
        }
        public void Representar()
        {
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 2; j++)
                {
                    Console.WriteLine(" {0} ", m2x2[i, j]);
                }
            }
        }
        public int Acceder(int fila, int columna)
        {
            int acc = m2x2[fila, columna];
            return acc;
        }

    }
}
