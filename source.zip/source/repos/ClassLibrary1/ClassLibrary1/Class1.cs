﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Class1
    {
        CMatriz2x2 m1 = new CMatriz2x2();
        m1.Representar();
      
    }
}
