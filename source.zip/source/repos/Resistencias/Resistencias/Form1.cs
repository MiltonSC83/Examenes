﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CircuitoResistencias;

namespace Resistencias
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void RSER_button_Click(object sender, EventArgs e)
        {
            if(R3_textBox.Text == "")
            {
                if(R1_textBox.Text == "" || R2_textBox.Text == "")
                {
                    MessageBox.Show("No puede quedar vacío", "Error fatal", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    double R1 = double.Parse(R1_textBox.Text);
                    double R2 = double.Parse(R2_textBox.Text);
                    double RE = CResistenciaSerie.REquiv(R1, R2);

                    Eq_textBox.Text = RE.ToString();
                }
                
            }
            else
            {
                double R1 = double.Parse(R1_textBox.Text);
                double R2 = double.Parse(R2_textBox.Text);
                double R3 = double.Parse(R3_textBox.Text);
                double RE = CResistenciaSerie.REquiv(R1, R2, R3);

                Eq_textBox.Text = RE.ToString();
            }
        }

        private void RPAR_button_Click(object sender, EventArgs e)
        {
            if (R3_textBox.Text == "")
            {
                double R1 = double.Parse(R1_textBox.Text);
                double R2 = double.Parse(R2_textBox.Text);
                double RE = CREquivparalelo.REquivp(R1, R2);

                Eq_textBox.Text = RE.ToString();
            }
            else
            {
                double R1 = double.Parse(R1_textBox.Text);
                double R2 = double.Parse(R2_textBox.Text);
                double R3 = double.Parse(R3_textBox.Text);
                double RE = CREquivparalelo.REquivp(R1, R2, R3);

                Eq_textBox.Text = RE.ToString();
            }
        }
    }
}
