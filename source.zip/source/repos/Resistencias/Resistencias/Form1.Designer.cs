﻿namespace Resistencias
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.R3_textBox = new System.Windows.Forms.TextBox();
            this.R2_textBox = new System.Windows.Forms.TextBox();
            this.R1_textBox = new System.Windows.Forms.TextBox();
            this.RPAR_button = new System.Windows.Forms.Button();
            this.RSER_button = new System.Windows.Forms.Button();
            this.Eq_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Ohms = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // R3_textBox
            // 
            this.R3_textBox.Location = new System.Drawing.Point(135, 210);
            this.R3_textBox.Name = "R3_textBox";
            this.R3_textBox.Size = new System.Drawing.Size(100, 20);
            this.R3_textBox.TabIndex = 0;
            // 
            // R2_textBox
            // 
            this.R2_textBox.Location = new System.Drawing.Point(135, 131);
            this.R2_textBox.Name = "R2_textBox";
            this.R2_textBox.Size = new System.Drawing.Size(100, 20);
            this.R2_textBox.TabIndex = 1;
            // 
            // R1_textBox
            // 
            this.R1_textBox.Location = new System.Drawing.Point(135, 56);
            this.R1_textBox.Name = "R1_textBox";
            this.R1_textBox.Size = new System.Drawing.Size(100, 20);
            this.R1_textBox.TabIndex = 2;
            // 
            // RPAR_button
            // 
            this.RPAR_button.Location = new System.Drawing.Point(293, 175);
            this.RPAR_button.Name = "RPAR_button";
            this.RPAR_button.Size = new System.Drawing.Size(142, 23);
            this.RPAR_button.TabIndex = 3;
            this.RPAR_button.Text = "Resistencia en paralelo";
            this.RPAR_button.UseVisualStyleBackColor = true;
            this.RPAR_button.Click += new System.EventHandler(this.RPAR_button_Click);
            // 
            // RSER_button
            // 
            this.RSER_button.Location = new System.Drawing.Point(293, 83);
            this.RSER_button.Name = "RSER_button";
            this.RSER_button.Size = new System.Drawing.Size(142, 23);
            this.RSER_button.TabIndex = 4;
            this.RSER_button.Text = "Resistencia en serie";
            this.RSER_button.UseVisualStyleBackColor = true;
            this.RSER_button.Click += new System.EventHandler(this.RSER_button_Click);
            // 
            // Eq_textBox
            // 
            this.Eq_textBox.Location = new System.Drawing.Point(448, 131);
            this.Eq_textBox.Name = "Eq_textBox";
            this.Eq_textBox.ReadOnly = true;
            this.Eq_textBox.Size = new System.Drawing.Size(100, 20);
            this.Eq_textBox.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Resistencia 3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Resistencia 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Resistencia 1";
            // 
            // Ohms
            // 
            this.Ohms.AutoSize = true;
            this.Ohms.Location = new System.Drawing.Point(554, 134);
            this.Ohms.Name = "Ohms";
            this.Ohms.Size = new System.Drawing.Size(34, 13);
            this.Ohms.TabIndex = 9;
            this.Ohms.Text = "Ohms";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Ohms);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Eq_textBox);
            this.Controls.Add(this.RSER_button);
            this.Controls.Add(this.RPAR_button);
            this.Controls.Add(this.R1_textBox);
            this.Controls.Add(this.R2_textBox);
            this.Controls.Add(this.R3_textBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox R3_textBox;
        private System.Windows.Forms.TextBox R2_textBox;
        private System.Windows.Forms.TextBox R1_textBox;
        private System.Windows.Forms.Button RPAR_button;
        private System.Windows.Forms.Button RSER_button;
        private System.Windows.Forms.TextBox Eq_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Ohms;
    }
}

