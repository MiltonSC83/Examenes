﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Checkbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void texto_label_CheckedChanged(object sender, EventArgs e)
        {
            texto_label.Font = new Font(texto_label.Font.Name, 16, texto_label.Font.Style ^ FontStyle.Bold);
        }

        private void Bold_label_FontChanged(object sender, EventArgs e)
        {
            texto_label.Font = new Font(texto_label.Font.Name,16,texto_label.Font.Style ^ FontStyle.Bold);
        }

        private void italic_label_CheckedChanged(object sender, EventArgs e)
        {
            texto_label.Font = new Font(texto_label.Font.Name, 16, texto_label.Font.Style ^ FontStyle.Italic);
        }

        private void underline_label_Checkedchanged(object sender, EventArgs e)
        {
            texto_label.Font = new Font(texto_label.Font.Name, 16, texto_label.Font.Style ^ FontStyle.Underline);
        }

        private void Tamaño_label(object sender, EventArgs e)
        {
            if(sender == T20_label)
            {
                texto_label.Font = new Font(texto_label.Font.Name, 20);
            }
            else if(sender == T8_label)
            {
                texto_label.Font = new Font(texto_label.Font.Name, 8);
            }
        }

        private void Tamaño_RadioButton(object sender, EventArgs e)
        {
            if (sender == T20_radioButton)
            {
                texto_label.Font = new Font(texto_label.Font.Name, 20);
            }
            else if (sender == T8_radioButton)
            {
                texto_label.Font = new Font(texto_label.Font.Name, 8);
            }
        }
    }
}
