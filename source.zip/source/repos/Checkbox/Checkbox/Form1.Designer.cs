﻿namespace Checkbox
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.texto_label = new System.Windows.Forms.CheckBox();
            this.italic_label = new System.Windows.Forms.CheckBox();
            this.Bold_label = new System.Windows.Forms.CheckBox();
            this.underline_label = new System.Windows.Forms.CheckBox();
            this.T20_label = new System.Windows.Forms.CheckBox();
            this.T8_label = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.T8_radioButton = new System.Windows.Forms.RadioButton();
            this.T20_radioButton = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // texto_label
            // 
            this.texto_label.AutoSize = true;
            this.texto_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texto_label.Location = new System.Drawing.Point(225, 92);
            this.texto_label.Name = "texto_label";
            this.texto_label.Size = new System.Drawing.Size(245, 37);
            this.texto_label.TabIndex = 0;
            this.texto_label.Text = "Texto de prueba";
            this.texto_label.UseVisualStyleBackColor = true;
            // 
            // italic_label
            // 
            this.italic_label.AutoSize = true;
            this.italic_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.italic_label.Location = new System.Drawing.Point(202, 32);
            this.italic_label.Name = "italic_label";
            this.italic_label.Size = new System.Drawing.Size(100, 29);
            this.italic_label.TabIndex = 1;
            this.italic_label.Text = "cursiva";
            this.italic_label.UseVisualStyleBackColor = true;
            this.italic_label.CheckedChanged += new System.EventHandler(this.italic_label_CheckedChanged);
            // 
            // Bold_label
            // 
            this.Bold_label.AutoSize = true;
            this.Bold_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bold_label.Location = new System.Drawing.Point(36, 32);
            this.Bold_label.Name = "Bold_label";
            this.Bold_label.Size = new System.Drawing.Size(119, 29);
            this.Bold_label.TabIndex = 2;
            this.Bold_label.Text = "Negritas";
            this.Bold_label.UseVisualStyleBackColor = true;
            this.Bold_label.CheckedChanged += new System.EventHandler(this.texto_label_CheckedChanged);
            this.Bold_label.FontChanged += new System.EventHandler(this.Bold_label_FontChanged);
            // 
            // underline_label
            // 
            this.underline_label.AutoSize = true;
            this.underline_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.underline_label.Location = new System.Drawing.Point(347, 32);
            this.underline_label.Name = "underline_label";
            this.underline_label.Size = new System.Drawing.Size(135, 29);
            this.underline_label.TabIndex = 3;
            this.underline_label.Text = "Subrayado";
            this.underline_label.UseVisualStyleBackColor = true;
            this.underline_label.CheckedChanged += new System.EventHandler(this.underline_label_Checkedchanged);
            // 
            // T20_label
            // 
            this.T20_label.AutoSize = true;
            this.T20_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T20_label.Location = new System.Drawing.Point(36, 343);
            this.T20_label.Name = "T20_label";
            this.T20_label.Size = new System.Drawing.Size(55, 29);
            this.T20_label.TabIndex = 4;
            this.T20_label.Text = "20";
            this.T20_label.UseVisualStyleBackColor = true;
            this.T20_label.CheckedChanged += new System.EventHandler(this.Tamaño_label);
            // 
            // T8_label
            // 
            this.T8_label.AutoSize = true;
            this.T8_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T8_label.Location = new System.Drawing.Point(36, 308);
            this.T8_label.Name = "T8_label";
            this.T8_label.Size = new System.Drawing.Size(43, 29);
            this.T8_label.TabIndex = 5;
            this.T8_label.Text = "8";
            this.T8_label.UseVisualStyleBackColor = true;
            this.T8_label.CheckedChanged += new System.EventHandler(this.Tamaño_label);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.T8_radioButton);
            this.groupBox1.Controls.Add(this.T20_radioButton);
            this.groupBox1.Location = new System.Drawing.Point(533, 308);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // T8_radioButton
            // 
            this.T8_radioButton.AutoSize = true;
            this.T8_radioButton.Location = new System.Drawing.Point(56, 59);
            this.T8_radioButton.Name = "T8_radioButton";
            this.T8_radioButton.Size = new System.Drawing.Size(73, 17);
            this.T8_radioButton.TabIndex = 1;
            this.T8_radioButton.TabStop = true;
            this.T8_radioButton.Text = "Tamaño 8";
            this.T8_radioButton.UseVisualStyleBackColor = true;
            this.T8_radioButton.CheckedChanged += new System.EventHandler(this.Tamaño_RadioButton);
            // 
            // T20_radioButton
            // 
            this.T20_radioButton.AutoSize = true;
            this.T20_radioButton.Location = new System.Drawing.Point(56, 35);
            this.T20_radioButton.Name = "T20_radioButton";
            this.T20_radioButton.Size = new System.Drawing.Size(79, 17);
            this.T20_radioButton.TabIndex = 0;
            this.T20_radioButton.TabStop = true;
            this.T20_radioButton.Text = "Tamaño 20";
            this.T20_radioButton.UseVisualStyleBackColor = true;
            this.T20_radioButton.CheckedChanged += new System.EventHandler(this.Tamaño_RadioButton);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.T8_label);
            this.Controls.Add(this.T20_label);
            this.Controls.Add(this.underline_label);
            this.Controls.Add(this.Bold_label);
            this.Controls.Add(this.italic_label);
            this.Controls.Add(this.texto_label);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox texto_label;
        private System.Windows.Forms.CheckBox italic_label;
        private System.Windows.Forms.CheckBox Bold_label;
        private System.Windows.Forms.CheckBox underline_label;
        private System.Windows.Forms.CheckBox T20_label;
        private System.Windows.Forms.CheckBox T8_label;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton T8_radioButton;
        private System.Windows.Forms.RadioButton T20_radioButton;
    }
}

