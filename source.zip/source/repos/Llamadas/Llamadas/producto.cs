﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Llamadas
{
    class producto();
    {



        private string Nombre;
        private byte Clave;
        private int Cantidad;
        private int CantidadenExistencia(stock);
        private float Costo;


        public Productos()
        {
        this.Nombre = Trapeador;
        this.Clave = 1234;
        this.Cantidad = 4;
        this.CantidadenExistencia=;

         



        }


    }
}
