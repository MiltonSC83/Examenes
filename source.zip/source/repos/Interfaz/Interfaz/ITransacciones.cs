﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaz
{
    public interface ITransacciones
    {
      void muestraTransacciones();
      double getmonto();
 
    }
}
