﻿using System;

namespace OrdenamientoG1_2019
{
    class Program
    {
        static void Main()
        {
            int [] V = { 10, 9, 20, 30, 15, 50 };
            Console.WriteLine("Ingresa la longitud de tu vector");
            int N = int.Parse(Console.ReadLine());
            Random aleatorio = new Random();
            byte[] buffer = new byte[N];
            V = new int[N];
            aleatorio.NextBytes(buffer);
            for(int i=0; i< N;i++)
            {
                V[i] = (int)buffer[i];

            }




            mostrar(V);
            burbuja(V);
            mostrar(V);
        }


       

        static void mostrar(int [] V)
        {
            for(int i =0; i < V.Length;i++)
            {

                Console.WriteLine("{0}", V[i]);
            }

            Console.WriteLine("\n **************************************");
        }

        static void burbuja(int [] V)
        {
            int aux = 0;
            for(int i=0; i < V.Length; i ++)
            {
                for(int j=0;j < V.Length-1;j++)
                {

                    if(V[j]< V[j+1])
                    {
                        aux = V[j];
                        V[j] = V[j + 1];
                        V[j + 1] = aux;

                    }

                }



            }
        }

    }
}
