﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tecnicas_de_programacion_2018_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("1              Tecnicas de programacion           l");
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("1 Nombre: ");
            Console.WriteLine("1 Grupo: ");
            Console.WriteLine("1 Carrera: ");
            Console.WriteLine("1 Tema: ");
            Console.WriteLine("---------------------------------------------------");

            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("I  Ley de Coulomb  I");
            Console.WriteLine("---------------------------------------------------");

            //ingresar las entradas

            double k = 9e9;
            double q1 = 100e-9;
            double q2 = 25e-9;
            double d = 0.04;

            //ingresando funcion

            double F = k * (q1 * q2) / (d * d);
            Console.WriteLine("La fuerza es: "+F);
            
            Console.ReadKey();
        }
    }
}
