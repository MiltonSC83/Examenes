﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace OrdenamientoyBusqueda
{
    public partial class Form1 : Form
    {
        int[] v;
        Random random = new Random();
        byte[] buffer = new byte[10];

        public Form1()
        {
            InitializeComponent();
  
            v = new int[10];
            random.NextBytes(buffer);
            for (int i=0; i<10; i++)
            {
                v[i] = (int)buffer[i];
            }
            lbNumeros.Text = Imprimir(v);

        }

        
        public static string Imprimir(int[] v)
        {
            string numeros="";
            for (int i = 0; i < v.Length; i++)
            {
                numeros = numeros + "       " + v[i];
            }
            return numeros;
        }

        private void btnNuevos_Click(object sender, EventArgs e)
        {
            random.NextBytes(buffer);
            for (int i = 0; i < 10; i++)
            {
                v[i] = (int)buffer[i];
            }
            lbNumeros.Text = Imprimir(v);
        }
    }
}
