﻿namespace ManejoMatrices
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mr_11_textBox = new System.Windows.Forms.TextBox();
            this.mr_10_textBox = new System.Windows.Forms.TextBox();
            this.mr_01_textBox = new System.Windows.Forms.TextBox();
            this.mr_00_textBox = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.m2x2_11_textBox = new System.Windows.Forms.TextBox();
            this.m2x2_10_textBox = new System.Windows.Forms.TextBox();
            this.m2x2_01_textBox = new System.Windows.Forms.TextBox();
            this.m2x2_00_textBox = new System.Windows.Forms.TextBox();
            this.Escalar_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // mr_11_textBox
            // 
            this.mr_11_textBox.Location = new System.Drawing.Point(654, 206);
            this.mr_11_textBox.Name = "mr_11_textBox";
            this.mr_11_textBox.Size = new System.Drawing.Size(100, 20);
            this.mr_11_textBox.TabIndex = 0;
            // 
            // mr_10_textBox
            // 
            this.mr_10_textBox.Location = new System.Drawing.Point(535, 206);
            this.mr_10_textBox.Name = "mr_10_textBox";
            this.mr_10_textBox.Size = new System.Drawing.Size(100, 20);
            this.mr_10_textBox.TabIndex = 1;
            // 
            // mr_01_textBox
            // 
            this.mr_01_textBox.Location = new System.Drawing.Point(654, 170);
            this.mr_01_textBox.Name = "mr_01_textBox";
            this.mr_01_textBox.Size = new System.Drawing.Size(100, 20);
            this.mr_01_textBox.TabIndex = 2;
            // 
            // mr_00_textBox
            // 
            this.mr_00_textBox.Location = new System.Drawing.Point(535, 170);
            this.mr_00_textBox.Name = "mr_00_textBox";
            this.mr_00_textBox.Size = new System.Drawing.Size(100, 20);
            this.mr_00_textBox.TabIndex = 3;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(319, 186);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 4;
            // 
            // m2x2_11_textBox
            // 
            this.m2x2_11_textBox.Location = new System.Drawing.Point(171, 206);
            this.m2x2_11_textBox.Name = "m2x2_11_textBox";
            this.m2x2_11_textBox.Size = new System.Drawing.Size(100, 20);
            this.m2x2_11_textBox.TabIndex = 5;
            // 
            // m2x2_10_textBox
            // 
            this.m2x2_10_textBox.Location = new System.Drawing.Point(52, 206);
            this.m2x2_10_textBox.Name = "m2x2_10_textBox";
            this.m2x2_10_textBox.Size = new System.Drawing.Size(100, 20);
            this.m2x2_10_textBox.TabIndex = 6;
            // 
            // m2x2_01_textBox
            // 
            this.m2x2_01_textBox.Location = new System.Drawing.Point(171, 170);
            this.m2x2_01_textBox.Name = "m2x2_01_textBox";
            this.m2x2_01_textBox.Size = new System.Drawing.Size(100, 20);
            this.m2x2_01_textBox.TabIndex = 7;
            // 
            // m2x2_00_textBox
            // 
            this.m2x2_00_textBox.Location = new System.Drawing.Point(52, 170);
            this.m2x2_00_textBox.Name = "m2x2_00_textBox";
            this.m2x2_00_textBox.Size = new System.Drawing.Size(100, 20);
            this.m2x2_00_textBox.TabIndex = 8;
            // 
            // Escalar_button
            // 
            this.Escalar_button.Location = new System.Drawing.Point(344, 296);
            this.Escalar_button.Name = "Escalar_button";
            this.Escalar_button.Size = new System.Drawing.Size(187, 50);
            this.Escalar_button.TabIndex = 9;
            this.Escalar_button.Text = "Multiplicación por un escalar";
            this.Escalar_button.UseVisualStyleBackColor = true;
            this.Escalar_button.Click += new System.EventHandler(this.Escalar_button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(496, 189);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(760, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(446, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(278, 189);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 189);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "label5";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Escalar_button);
            this.Controls.Add(this.m2x2_00_textBox);
            this.Controls.Add(this.m2x2_01_textBox);
            this.Controls.Add(this.m2x2_10_textBox);
            this.Controls.Add(this.m2x2_11_textBox);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.mr_00_textBox);
            this.Controls.Add(this.mr_01_textBox);
            this.Controls.Add(this.mr_10_textBox);
            this.Controls.Add(this.mr_11_textBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox mr_11_textBox;
        private System.Windows.Forms.TextBox mr_10_textBox;
        private System.Windows.Forms.TextBox mr_01_textBox;
        private System.Windows.Forms.TextBox mr_00_textBox;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox m2x2_11_textBox;
        private System.Windows.Forms.TextBox m2x2_10_textBox;
        private System.Windows.Forms.TextBox m2x2_01_textBox;
        private System.Windows.Forms.TextBox m2x2_00_textBox;
        private System.Windows.Forms.Button Escalar_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

