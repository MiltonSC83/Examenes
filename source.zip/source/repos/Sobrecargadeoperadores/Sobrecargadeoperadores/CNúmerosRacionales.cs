﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjemploNúmerosRacionales
{
    class CNúmerosRacionales
    {
        //Atributos
        private int denominador, numerador;

        //Constructores
        public CNúmerosRacionales(int d, int n)
        {
            denominador = d;
            numerador = n;
        }

        public CNúmerosRacionales()
        {
            
            denominador = 1;
            numerador = 1;
        }

        public CNúmerosRacionales (int entero)
        {
            numerador = entero;
            denominador = 1;
        }

        //Propiedades
        public int Numerador
        {
            set { numerador = value; }
            get { return numerador; }
        }

        public int Denominador
        {
            set { denominador = value; }
            get { return denominador; }
        }

        //Métodos
        public string RepresentarNR()
        {
            string NR = numerador.ToString() + "/" + denominador.ToString();

            return NR;
        }

        //Covertir a número fraccionario
        public double ConvertirAFraccionario()
        {
            double NumFracc = Convert.ToDouble(numerador)/ Convert.ToDouble(denominador);
            return NumFracc;
        }

        public static CNúmerosRacionales operator *(CNúmerosRacionales n1, CNúmerosRacionales n2)
        {
            CNúmerosRacionales Res = new CNúmerosRacionales(n1.Denominador * n2.Denominador, n1.Numerador * n2.Numerador);
            return Res;
        }




    }
}
