﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sobrecargadeoperadores
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Multiplicación de números racionales \n\nDame el denominador del primer número. ");
            int d1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Dame el numerador del primer número: ");
            int n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Dame el denominador del segundo número: ");
            int d2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Dame el numerador del segundo número: ");
            int n2 = int.Parse(Console.ReadLine());

            EjemploNúmerosRacionales.CNúmerosRacionales fracc1 = new EjemploNúmerosRacionales.CNúmerosRacionales(d1, n1);
            EjemploNúmerosRacionales.CNúmerosRacionales fracc2 = new EjemploNúmerosRacionales.CNúmerosRacionales(d2, n2);

            Console.WriteLine("La multiplicación de {0} * {1} = {2}", fracc1.RepresentarNR(), fracc2.RepresentarNR(), (fracc1 * fracc2).RepresentarNR());

            Console.ReadKey();

        }
    }
}
