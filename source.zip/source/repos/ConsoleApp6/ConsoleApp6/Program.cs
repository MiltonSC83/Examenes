﻿using System;

namespace ConsoleApp6
{
    class Program
    { private Automovil;
            
        static void Main()
        {
            public Automovil;

        }
    }
}
