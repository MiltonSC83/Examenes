﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio18
{
    public class ReproductorMusical
    {
        [DllImport("winmm.dll")]
        //Indicar que método de la librería se quiere usar
        private static extern long mciSendString( string lpstrCommand,StringBuilder lpstrReturnString,
            int uReturnLength, int hwndCallback);


        public void Abrir(string archivo)
        {
            string comando = "open \""+archivo+"\" type MPEGVideo alias cancion";
            mciSendString(comando,null,0,0);
        }

        public void Reproducir ()
        {
            string comando = "play cancion";
            mciSendString(comando, null, 0, 0); //Los ceros se mandan a las variables de arriba 
            
        }

        public void Pausa()
        {
            string comando = "stop cancion";

            mciSendString(comando, null, 0, 0);
        }

        public void Reiniciar()
        {
            string comando = "seek cancion to start";

            mciSendString(comando, null, 0, 0);
        }

        public void Cerrar()
        {
            string comando = "close cancion";

            mciSendString(comando, null, 0, 0);
        }
    }
}
