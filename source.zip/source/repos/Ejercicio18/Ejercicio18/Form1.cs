﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio18
{
    public partial class Form1 : Form
    {
        private ReproductorMusical canción = new ReproductorMusical();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                //Swe convierte en lo que selecciona el usuario
                textBox1.Text =openFileDialog1.FileName;

                //Abriendo la canción 
                canción.Abrir(openFileDialog1.FileName);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            canción.Reproducir();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            canción.Pausa();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            canción.Reiniciar();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            canción.Cerrar();
        }


        /*
         Se puede seleccionar una lista de canciones
         de la lista con doble click se reproduce 
         contro de volumen
         avance de la canción 
         mover el tiempo de la cancion 
         botones de siguiete y atras
         revolver lista de reproducción 
         volver a reproducir la lista
         control de errores

         */
    }
}
