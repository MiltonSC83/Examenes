﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    class CCuenta
    {
        //Atributos
        private int numcuenta;
        private string nombre, RFC, direccion, contraseña;
        private double monto;

        //Constructor
        public CCuenta(int numcuenta, string nombre, string RFC, string direccion, string contraseña, double monto)
        {
            this.numcuenta = numcuenta;
            this.nombre = nombre;
            this.RFC = RFC;
            this.direccion = direccion;
            this.contraseña = contraseña;
            this.monto = monto;
        }

        //Propiedades
        public int Numcuenta
        {
            get { return numcuenta; }
        }
        public string Nombre
        {
            get { return nombre; }
        }
        public string rFC
        {
            get { return RFC; }
        }
        public int Direccion
        {
            get { return numcuenta; }
        }
        public string Contraseña
        {
            set { contraseña = value; }
            get { return contraseña; }
        }

        //Métodos
        public double Retiro(double cantidad)
        {
            monto = monto - cantidad;
            return monto;
        }
        public double Deposito(double cantidad)
        {
            monto += cantidad;
            return monto;
        }
        public double Revisarsaldo()
        {
            return monto;
        }
        public double Comision()
        {
            monto -= 0;
            return monto;
        }
        public double Intereses()
        {
            double intereses = monto * 0;
            monto -= intereses;
            return intereses;
        }
    }

}
