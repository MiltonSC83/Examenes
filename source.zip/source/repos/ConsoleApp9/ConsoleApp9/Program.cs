﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    class Program
    {
        static void Main(string[] args)
        {
            int op = 10, numal, s = 0;
            Random numerorandom = new Random();
            //Cambiar color de la consola
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Clear();

            Console.WriteLine("Bienvenido a banco Azteco, se creará tu cuenta");
            Console.WriteLine("Nombre: ");
            string nombre = Console.ReadLine();
            numal = numerorandom.Next(1000, 9999);
            Console.WriteLine("Tu número de cuenta es: {0}", numal);
            Console.WriteLine("escribe la contraseña de 4 dígitos: ");
            string c = Console.ReadLine();
            Console.WriteLine("¿Cuánto dinero quieres depositar inicialmente? ");
            double d = double.Parse(Console.ReadLine());

            CCuenta cuentausuario1 = new CCuenta(numal, nombre, "JAJA", "Fondo de bikini", c, d);
            do
            {
                switch (op)
                {
                    default:
                        Console.Clear();
                        Console.WriteLine("bienvenido a banco Azteco, ¿qué deseas hacer?");
                        Console.WriteLine("1.- Consulta");
                        Console.WriteLine("2.- Retiro");
                        Console.WriteLine("3.- Depósito");
                        Console.WriteLine("4.- Salir");
                        Console.WriteLine("selecciona una opción");
                        op = int.Parse(Console.ReadLine());
                        break;

                    case 1:
                        Console.Clear();
                        Console.WriteLine("Tu saldo es: {0:c}", cuentausuario1.Revisarsaldo());
                        Console.WriteLine("Presiona cualquier tecla para regresar");
                        Console.ReadKey();
                        op = 5;
                        break;

                    case 2:


                        break;


                    case 3:


                        break;


                    case 4:


                        break;

                }
            } while (s == 0);

            Console.WriteLine("tu saldo es: {0:c}", cuentausuario1.Revisarsaldo());

            Console.ReadKey();

        }
    }
}
