﻿using System;
using System.Collections;

namespace Nombres
{
    class Program
    {
        static void Main()
        {
            Refrigerador mirefri = new Refrigerador("LG", "2018");
            IApagar apagarRefrigerador = (IApagar)mirefri;
            apagarRefrigerador.Apagar();

            Estufa miEstufa = new Estufa("","");
            Console.WriteLine("Estufa \n marca: {0} \n modelo{1}", miEstufa.Marca, miEstufa.modelo);
            miEstufa.Apagar();



        }
    }
}