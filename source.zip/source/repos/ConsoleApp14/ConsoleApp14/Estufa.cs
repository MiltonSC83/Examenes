﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp14
{
    class Estufa:LineaBlanca,IApagar
    { 
        public Estufa(string Marca, string Modelo)
        {
            this.Marca = Marca;
            this.Modelo = Modelo;

        }

        public void Apagar()
        {
           Console.WriteLine("Apagando el Estufa");
        }
    }
}
