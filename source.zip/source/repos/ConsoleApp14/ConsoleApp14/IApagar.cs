﻿using System;


namespace ConsoleApp14
{
    interface IApagar
    {
        void Apagar();


    }
}
