﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp14
{
    abstract class LineaBlanca
    {
        #region
        private string marca;
        private string modelo;
        #endregion




        #region
        public string Marca
        {
            get => marca;
            set
            {
                if (value == "")
                {
                    marca = "Mabe";
                }
                else
                {
                    marca = value;

                }

            }
        }
        
            public string Modelo
             {
            get => modelo;

            set
            {
                if (value == "")
                {
                    modelo = "2018";
                }
                else
                {
                    marca = value;

                }

            }



             }

        #endregion


    }
}