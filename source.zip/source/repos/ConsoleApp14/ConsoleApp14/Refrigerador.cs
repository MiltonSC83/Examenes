﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp14
{
    class Refrigerador:IApagar
    {
        private string marca;
        private string modelo;


        public Refrigerador(string modelo, string marca)
        {
            this.marca = marca;
            this.modelo = modelo;

        }

        void IApagar.Apagar()
        {
            Console.WriteLine("Apagando Refrigerador \a");
        }


    }
}
