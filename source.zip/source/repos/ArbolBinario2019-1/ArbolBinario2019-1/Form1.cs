﻿using System;

using Arboles;
using System.Drawing;

using System.Windows.Forms;

namespace ArbolBinario2019_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Arbol arbolbinario = new Arbol(ptbArbol);
        }

       
    
        private void txtbIngresaDato_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar== (char)Keys.Enter)
            {
                arbolBinario = new Arbol(ptbArbol);
                arbolbinario.inserta_nodo(null, ArbolBinario.Raiz, int Parse(txtbDato.Text), 0);
                txtbDato.Clear;



           
            }
        }
    }
}
