﻿using System;

namespace La_llamada_XD
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Hola mundo");
            Console.ReadLine();
        }
    }
}
