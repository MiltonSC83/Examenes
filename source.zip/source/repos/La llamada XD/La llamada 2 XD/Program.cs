﻿using System;

namespace La_llamada_2_XD
{
    class Program
    {
        static void Main() { 
            double costo=0, total=0;
            int cont=0, min=0, llamada=0, bandera=0;
            do
            {
                Console.WriteLine("¿Qué tipo de llamada realizó? \nA) Internacional\nB) Nacional\nC)Local\nX)Terminar\n");
                char llamada = char.Parse(Console.ReadLine()); //Char parse convierte una cadena o un valor a caracter
                Console.WriteLine("¿Duración de la llamada\n");
                int min = Console.ReadLine(); 
                if (min == -1)
                {
                    int bandera = 1;
                }
                switch (llamada)
                {
                    case 'A':
                        if 
                }
            }
        }
    }
}
