﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejericicio14
{
    public class Círculo: Forma
    {
        public Círculo(int xInicial, int yInicial)
        {
           

        }

        public override void CambiarColor(int red, int green, int black)
        {
            
        }
        public override void Dibujar(Graphics papel)
        {
            papel.FillEllipse(brocha, x, y, tamaño,tamaño);
        }
    }
}
