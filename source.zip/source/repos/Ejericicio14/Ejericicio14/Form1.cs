﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejericicio14
{
    public partial class Form1 : Form
    {
        private Graphics papel;
        public Form1()
        {
            InitializeComponent();
            papel = pictureBox1.CreateGraphics();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            papel.Clear(Color.White);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            try //Checa si se genera un error 
            {
                int x = Convert.ToInt32(textBox1.Text);
            }

            catch (Exception error)
            {
                errorProvider1.SetError(textBox1, error.Message);
            }


            try //Checa si se genera un error 
            {
                int  y= Convert.ToInt32(textBox2.Text);
            }

            catch (Exception error)
            {
                errorProvider1.SetError(textBox2, error.Message);
            }
        }
    }
}
