﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejericicio14
{
    public abstract class Forma

    {
        //No se pueden crear objetos de una clase abstracta
        protected int x, y;
        protected int tamaño = 20;
        protected Brush brocha = new SolidBrush(Color.Black);
        public abstract void Dibujar(Graphics papel);
        //Cualquier clase que herede de esta clase forzozamente emplea 
        //Estos métodos sin tener que definir el método
        public abstract void CambiarColor(int red, int green, int black);

    }
}
