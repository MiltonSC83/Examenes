﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen1
{
    class Operacion
    {
        protected double numero1;
        protected double numero2;

        public void setnumero1(double n1)
        {
            numero1 = n1;
        }
        public void setnumero2(double n2)
        {
            numero2 = n2;
        }
    }
}
