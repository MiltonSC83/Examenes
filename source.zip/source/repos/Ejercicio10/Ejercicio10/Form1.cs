﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cadena1 = textBox1.Text;

            string cadena2 = textBox2.Text;

            //bool m = cadena1.StartsWith(cadena2);
            //textBox3.Text=m + "";

            //m = cadena1.EndsWith(cadena2);
            //textBox3.Text = m + "";

            int n = cadena1.CompareTo(cadena2);
            //textBox3.Text = n + "";

            //n = cadena1.IndexOf(cadena2);
            //textBox3.Text = "Mi nombre es \"Luis\"";
            //textBox3.Text = @"c:\archivo\foder\archivo.txt";

            // Con este comando te brinda los caracteres que van de la posición 5 y 3 adelante
            //string s = cadena1.Substring(5,3);
            //textBox3.Text = s;

            //string s = cadena1.Remove(2, 3);
            //textBox3.Text = s;

            //string s = cadena1.Insert(2, cadena2);
            //textBox3.Text = s;

            //string s = cadena1.Trim();
            //textBox3.Text = s;


            //string s = cadena1.TrimStart('a');
            //textBox3.Text = s;

            //Convierte en mayusculas

            //string s = cadena1.ToUpper();
            //textBox3.Text = s;

            //string s = cadena1.ToLower();
            //textBox3.Text = s;

            //n = cadena1.LastIndexOf(@"\");
            //textBox3.Text = n + "";

            string[] palabras;

            palabras = cadena1.Split(',');

            for (int i=0; i<palabras.Length;i++)
            {
                textBox3.Clear();
                textBox3.AppendText(palabras[i] + "\r\n");
            }
            textBox1.Text = n + "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog()==DialogResult.OK)
            {
                string[] archivos = Directory.GetFiles(folderBrowserDialog1.SelectedPath);
                
                foreach(string archivo in archivos)
                {
                    textBox3.AppendText(archivo + "'r'n");
                }

                string[] carpetas = Directory.GetDirectories(folderBrowserDialog1.SelectedPath);

                foreach (string carpeta in carpetas)
                {
                    textBox4.AppendText(carpeta + "'r'n");
                }
            }
            //using System.IO
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            string cadena1 = textBox1.Text;

            string cadena2 = textBox2.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
