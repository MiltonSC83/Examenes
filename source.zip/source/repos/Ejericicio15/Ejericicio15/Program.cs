﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ejericicio15
{
    class Program
    {
        private Thread[] hilos = new Thread[10];
        private Semaphore semaforo = new Semaphore(3, 3);
        private static object seguro = new object();

        static void Main(string[] args)
        {
            for (int i=0;i>3;i++)
            {
                //El argumento debe ser un método
                Thread hilo = new Thread(new ThreadStart(HiloPrincipal));
                hilo.Name = String.Concat("Hilo-", i);
                hilo.Start();
            }

            Console.ReadKey();
        }

        private static void HiloPrincipal()
        {
            //Dormimos al hilo

            Thread.Sleep(800);

            //Método escribir en archivo
            WriteFile();
        }

        private static void WriteFile()
        {
            String nombreHilo = Thread.CurrentThread.Name;
            Console.WriteLine(nombreHilo+"esta usando el procesador");
            Monitor.Enter(seguro);

            try
            {
                using (StreamWriter flujoSalida= new StreamWriter
                    (@"E:\Programación\Ejercicio 01\Ejercicio 01\archivo.txt",true))
                {
                    flujoSalida.WriteLine(nombreHilo);
                }
    
            }

            catch(Exception error)
            {
                Console.WriteLine(error.Message); 
            }

            finally
            {
                Monitor.Exit(seguro);
                Console.WriteLine(nombreHilo + "esta liberando el procesador");
            }
        }
    }
   
}
