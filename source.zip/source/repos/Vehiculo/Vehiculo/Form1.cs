﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vehiculo
{
    public partial class Form1 : Form
    {
        Automovil1 A1 = new Automovil1();
        Boolean Adelante = false;
        Boolean Atras = false;

        public Form1()
        {
            InitializeComponent();

            richTextBox1.Text = "El vehículo está avanzando";
            richTextBox1.Text = "El vehículo está detenido";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ("Avanzar" == this.comboBox1.SelectedItem.ToString()) ;
            {
                Adelante = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string velocodad = textBox1.Text;

            string accion = comboBox1.Text;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            public abstract int GetDistancia();
        }
    }
}
