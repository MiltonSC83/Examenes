﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculo
{
    class Automovil1
    {
        protected string Accion;
        protected int Distancia;
        protected Boolean Velocidad;

        public string Accion1 { get => Accion; set => Accion = value; }
        public int Distancia1 { get => Distancia; set => Distancia = value; }

        public void IdentificarAccion()
        {
            if(Accion == "Avanzar")
            {
                Velocidad = true;
            }
            else if(Accion == "Frenar")
            {
                Velocidad = false;
            }
            else if(Accion == "Esperar")
            {
                Velocidad = false;

            }
        }

        public void ActivarAlarma()
        {

        }
    }
}
