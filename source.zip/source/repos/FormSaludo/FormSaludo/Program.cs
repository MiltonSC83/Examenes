﻿using System;
using System.Windows.Forms;

namespace FormSaludo
{
    class Program
    {
        static void Main()
        {
            Application.Run(new FormIngresa());
        }
    }
}
