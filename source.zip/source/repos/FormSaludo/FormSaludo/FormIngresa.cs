﻿
namespace FormSaludo
{
    partial class FormIngresa
    {
        public FormIngresa()
        {
            IniciarComponentes();
        }
    }
}
