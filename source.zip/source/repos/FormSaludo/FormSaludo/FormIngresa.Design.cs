﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace FormSaludo
{
    partial class FormIngresa:Form
    { 

        #region Atributos 
        private Label etIntroduceNombre;
        private TextBox txtbNombre;
        private Button btnAceptar;
#endregion

        #region Método Iniciar
        private void IniciarComponentes()
        {
            // Definiendo las propiedades
            this.Text = "Ingresa";
            this.Size = new Size(400, 300);
            // this.Location = new Point(400, 100);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Construir los atributos, etiqueta
            etIntroduceNombre = new Label();
            etIntroduceNombre.Text = "Introduce tu nombre";
            etIntroduceNombre.Location = new Point(10, 20);
            etIntroduceNombre.Size = new Size(180, 35);
            etIntroduceNombre.Font = new Font("Comic Sans MS", 12, FontStyle.Bold);
            etIntroduceNombre.TextAlign = ContentAlignment.MiddleCenter;

            // Construir Textbox

            txtbNombre = new TextBox();
            txtbNombre.Location = new Point(18, 70);
            txtbNombre.Size = new Size(180, 25);
            txtbNombre.TextAlign = HorizontalAlignment.Center;

            // Construir Botón
            btnAceptar = new Button();
            btnAceptar.Location = new Point(60, 100);
            btnAceptar.Size = new Size(100, 20);
            btnAceptar.Text = "Aceptar";
            btnAceptar.TextAlign = ContentAlignment.MiddleCenter;

            this.Controls.Add(etIntroduceNombre);
            this.Controls.Add(txtbNombre);
            this.Controls.Add(btnAceptar);


        }
        #endregion
    }
}
