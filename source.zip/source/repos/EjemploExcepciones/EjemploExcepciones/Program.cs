﻿using System;

namespace EjemploExcepciones
{
    class Program
    {
        static void Main()
        {
            bool err = false;

            do
            {



                try
                {
                    Console.WriteLine("Ingresa un número entero");
                    int num = int.Parse(Console.ReadLine());
                    Console.WriteLine("Ingresa un segundo número");
                    int num2 = int.Parse(Console.ReadLine());
                    if (num2 < 0)
                    {
                        string error = "El numerador no puede ser negativo";
                        throw new ApplicationException(error);
                    }

                    int result = num / num2;
                    Console.WriteLine("{0}", result);
                    err = false;

                }
                catch (ApplicationException error)
                {
                    err = true;
                    // Este mensaje va dirigido al programador
                    Console.WriteLine(error);
                    // Este mensaje solamente va dirigido al usuario del programa
                    //Console.WriteLine(error.Message);
                }
                catch (DivideByZeroException error)
                {
                    err = true;
                    Console.WriteLine(error.Message);
                }
                catch (FormatException)
                {
                    err = true;
                    Console.WriteLine("Tipo de dato inválido");
                }
                catch
                {
                    err = true;
                    Console.WriteLine("OOPS! Hubo un error");
                }
                finally
                {
                    Console.WriteLine("Se ejecuta de cualquier manera");

                }
            }
            while (err);
        }
    }
}
