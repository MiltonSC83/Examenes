﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp17
{
    class CMatriz3x3
    {
        //Atributos
        int[,] m3x3;
        int a = 0;

        //Constructor
        public CMatriz3x3(int fila, int columna)
        {
            m3x3 = new int[fila, columna];
        }
        public CMatriz3x3()
        {
            Random numaleatorio = new Random();
            
            m3x3 = new int[3, 3];
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    int s = 1;
                    do
                    {
                        int n = numaleatorio.Next(0, 9);

                        if (Acceder(0, 0) != n && Acceder(0, 1) != n && Acceder(0, 2) != n && Acceder(1, 0) != n && Acceder(1, 1) != n && Acceder(1, 2) != n Acceder(2, 0) != n &&)
                        {
                            Modificar(i, j, n);
                            s = 3;
                        }
                    } while (s == 1);              
                }

            }
        }


        //Métodos
        public void Representar()
        {
            for(int i = 0; i < 3; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    Console.Write(" {0} ", m3x3[i, j]);
                }
                Console.WriteLine();
            }
        }
        public int Acceder(int fila, int columna)
        {
            int acc = m3x3[fila, columna];
            return acc;
        }
        public void Modificar(int fila, int columna, int valor)
        {
            m3x3[fila, columna] = valor;
        }
        public void Multiplicarporunescalar(int escalar)
        {
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    Modificar(i, j, (escalar * Acceder(i, j)));
                }
            }
        }
    }
}
