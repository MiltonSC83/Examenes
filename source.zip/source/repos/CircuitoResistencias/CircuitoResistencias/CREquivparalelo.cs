﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CircuitoResistencias
{
    public class CREquivparalelo
    {
        public static double REquivp(double r1, double r2)
        {
            return 1 / ((1 / r1) + (1 / r2));
        }
        public static double REquivp(double r1, double r2, double r3)
        {
            return 1 / ((1 / r1) + (1 / r2) + (1 / r3));
        }
    }
}
