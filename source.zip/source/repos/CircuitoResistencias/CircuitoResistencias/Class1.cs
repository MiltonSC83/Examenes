﻿using System;

namespace CircuitoResistencias
{
    public class CResistenciaSerie
    {
        //Para dos resistencias e el circuito
        public static double REquiv(double r1, double r2)
        {
            return r1 + r2;
        }
        public static double REquiv(double r1, double r2, double r3)
        {
            return r1 + r2 + r3;
        }
        
    }
}
