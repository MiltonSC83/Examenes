﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("La fuerza");
            Console.Title = "Metodos";

            double a = 5;
            double b = 6;
            //puedo ponerlo de este modo suma(a,b,c)
            //podemos poner los metodos que queramos con el mismo nombre pero no con las mismas variables
            //double c = suma(a, b);
            Saludo("Jason");
           

            //Console.WriteLine("El valor de c: " + c);
            Console.ReadKey();
        }
        /// <summary>
        /// Suma 2 valores ingresados
        /// </summary>
        /// <param name="a"> variable a</param>
        /// <param name="b"> variable b</param>
        /// <returns>devuelve un double que es suma de 2 numeros</returns>
        public static double suma (double a, double b)
        {
            double output = a + b;

            return output;
        }

        /// <summary>
        /// Suma 3 valores ingresados
        /// </summary>
        /// <param name="a">variable a</param>
        /// <param name="b">variable b</param>
        /// <param name="c">variable c</param>
        /// <returns></returns>
        
        public static double suma(double a, double b, double c)
        {
            double output = a + b + c;

            return output;
        }
        public static string suma(double a)
        {
            double output = 0;

            return "hola";
        }
        public static void Saludo(string nombre)
        {
            Console.WriteLine("Hola {0}", nombre);
        }
    }
}
